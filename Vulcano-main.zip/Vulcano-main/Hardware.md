# Hardware

### Example of hardware

- Controller
    - ESP32 / Arduino Uno, Nano, Mega
- Motor Driver
    - L298, DRV8835, TB6612FNG
- Motor
    - Micro Motor DC 6V
- Sensors
    - Flame Sensor 
    - Ultrasonic Sensor
    - Temperature Sensor
