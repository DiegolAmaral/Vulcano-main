# Vulcano

Aconselhamos a instalação do seguinte software: <br>
<a href="https://code.visualstudio.com/" target="_blank"> Visual Studio Code </a>

Para podermos comunicar com o microcontrolador ESP32 da Espressif necessitamos de instalar no Visual Studio Code o IDE PlatformIO: <br>
<a href="https://platformio.org/install/ide?install=vscode" target="_blank"> PlatformIO </a>

<a href="https://robotics-and-ai-group-of-uac.github.io/Vulcano/"> Voltar à página inicial </a>
